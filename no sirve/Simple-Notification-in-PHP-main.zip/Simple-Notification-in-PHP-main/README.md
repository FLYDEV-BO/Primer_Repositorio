# Simple-Notification-in-PHP
PHP simple notification using AJAX PHP Mysql
