# SimpleNotification
This is a simple notification created by PHP-MySql and Ajax. Also it contains a simple registration and logIn page.
You need to attach the sql file and change your mysql connection credentials on DbConnect.php. Please use it and give me some feedback. 
There are many features I am going to add in near future. Such as using Socket I/O and user based notification system. 
