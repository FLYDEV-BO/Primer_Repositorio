<?php 
//connect.php;
$connect = mysqli_connect("localhost", "root", "", "dw_ajax");
?>